from django.db import models

class Book(models.Model):
    bookID = models.IntegerField(primary_key = True)
    title = models.CharField(max_length=200)
    authors = models.CharField(max_length=200)
    release_date = models.DateTimeField('date published')
    type = models.CharField(max_length=200)
    Availability = models.CharField(max_length=200)

    def __str__(self):
        s = ('Book ID: ' + str(self.bookID) + '\n' + '| Book title is: ' + str(self.title) + '\n| Authors are: ' + str(self.authors) + '\n| Release Date is: ' + str(self.release_date) + '\nBook type is: ' + str(self.type) + '\n| Availability: ' + str(self.Availability) + '\n \n \n')
        return s

class Books_Members(models.Model):
    bookID = models.ForeignKey(Book, on_delete=models.CASCADE
    )
    UserID = models.CharField(max_length=200)


class Ratings(models.Model):
    bookID = models.ForeignKey(
    Book, on_delete=models.CASCADE
    )
    UserID = models.CharField(max_length=200)
    Rating = models.IntegerField()

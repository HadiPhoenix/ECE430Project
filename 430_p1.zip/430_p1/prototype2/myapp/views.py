from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.contrib.auth import get_user_model
from django.db import transaction

from .models import Book, Books_Members, Ratings

def index(request):
    return render(request, 'home.html', {})

def books(request):
    all_books = Book.objects.all
    return render(request, 'books.html', {'all':all_books})

def ReturnUsers(request):
    User = get_user_model()
    all_users = User.objects.all()
    return render(request, 'usres.html', {'all':all_users})

def book_by_id(request, book_id):
    book = Book.objects.get(pk=book_id)
    return render(request, 'book_details.html', {'book':book})

def rent_book(request):
    if request.method == "POST":
        rent = request.POST['rent']
        book = Book.objects.get(pk=rent)
        book.Availability = "Not Available"
        book.save()
        T1 = Books_Members.objects.create(UserID = "Hadi", bookID = book)
        T1.save()

        return render(request, 'rent.html', {'book':book})

    else:
        return render(request, 'rent.html', {'book':book})


def return_book(request):
    if request.method == "POST":
        rent = request.POST['rent']
        book = Book.objects.get(pk=rent)
        book.Availability = "Available"
        book.save()
        T1 = Books_Members.objects.get(UserID = "Hadi", bookID = book)
        T1.delete()
        T1.save()

        return render(request, 'rent.html', {'book':book})

    else:
        return render(request, 'rent.html', {'book':book})

def my_books(request):
    book = Books_Members.objects.get(UserID = "Hadi")
    return render(request, 'listbook.html', {'book': book})

def search_books(request):
    if request.method == "POST":
        searched = request.POST['searched']
        books = Book.objects.filter(title__contains=searched)
        return render(request, 'myapp/search_books.html', {'searched':searched, 'books':books})

    else:
        return render(request, 'myapp/search_books.html', {})

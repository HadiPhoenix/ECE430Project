from django.contrib import admin

from .models import Book, Books_Members, Ratings
admin.site.register(Book)
admin.site.register(Books_Members)
admin.site.register(Ratings)
